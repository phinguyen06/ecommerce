/*
 * Copyright 2005 PayPal, Inc. All Rights Reserved.
 */

package com.paypal.sdk.profiles;

import java.text.MessageFormat;

import com.paypal.sdk.exceptions.PayPalException;
import com.paypal.sdk.exceptions.TransactionException;

import com.paypal.sdk.util.MessageResources;
import com.paypal.sdk.util.SDKResources;

/**
 * Utility class used to create profile objects.
 * @author PayPal DTS
 */
public class ProfileFactory
{
    private static final String DEFAULT_SSL_API_PROFILE = "com.paypal.sdk.profiles.CertificateAPIProfile";

    private static final String DEFAULT_SIGNATURE_API_PROFILE = "com.paypal.sdk.profiles.SignatureAPIProfile";

    private static final String DEFAULT_EWP_PROFILE = "com.paypal.sdk.profiles.DefaultEWPProfile";

    /**
     * Create a blank SSL API Profile
     * @return new API Profile
     */
    public static APIProfile createSSLAPIProfile() throws PayPalException
    {
        try
        {
            APIProfile profile = (APIProfile) Class.forName(DEFAULT_SSL_API_PROFILE).newInstance();
            return profile;
        }
        catch (Exception e)
        {
            throw new TransactionException(MessageFormat.format(MessageResources
                    .getMessage("PROFILE_INSTANTIATION_ERROR"),
                    new Object[] { DEFAULT_SSL_API_PROFILE }));
        }
    } // createSSLAPIProfile

    /**
     * Create a blank SSL API Profile
     * @return new API Profile
     */
    public static APIProfile createSignatureAPIProfile() throws PayPalException
    {
        try
        {
            APIProfile profile = (APIProfile) Class.forName(DEFAULT_SIGNATURE_API_PROFILE)
                    .newInstance();
            return profile;
        }
        catch (Exception e)
        {
            throw new TransactionException(MessageFormat.format(MessageResources
                    .getMessage("PROFILE_INSTANTIATION_ERROR"),
                    new Object[] { DEFAULT_SIGNATURE_API_PROFILE }));
        }
    } // createSSLAPIProfile

    /**
     * Create a blank EWP Profile
     * @return new EWPProfile
     */
    public static EWPProfile createEWPProfile() throws PayPalException
    {
        try
        {
            EWPProfile profile = (EWPProfile) Class.forName(DEFAULT_EWP_PROFILE).newInstance();
            return profile;
        }
        catch (Exception e)
        {
            throw new TransactionException(MessageFormat.format(MessageResources
                    .getMessage("PROFILE_INSTANTIATION_ERROR"),
                    new Object[] { DEFAULT_EWP_PROFILE }));
        }
    } // createEWPProfile
} // ProfileFactory