README for PayPal Java SDK Boarding Sample
==========================================

Steps to run the Java SDK for PayPal NVP API Boarding Sample:

1. Download and install the following required software.

   Software:          Version:       Download from:
   =========          ========       ==============
   J2SE 1.4.2 SDK     1.4.2          http://java.sun.com/j2se/1.4.2/download.html
   Apache Tomcat      4.1 or 5.0     http://tomcat.apache.org/

2. Copy the <PayPal SDK ROOT>\samples\JSP\dist\paypaljsp.war file to your Tomcat 
   webapps folder (<TOMCAT ROOT>\webapps\).

3. Restart Apache Tomcat.

4. Using Tomcat's default configuration running on your local machine, to access the 
   PayPal Java SDK Boarding Sample homepage, open the following URL:

   http://localhost:8080/paypaljsp/

5. Select the default API Sandbox account, or enter your own API credentials.

6. The PayPal log file (paypaljsp.log) will be created under <TOMCAT ROOT>\logs\.

Steps to build the PayPal Java SDK JSP Sample:

1. Download and install the following required software.

   Software:          Version:       Download from:
   =========          ========       ==============
   Apache Ant         1.6.5          http://ant.apache.org/bindownload.cgi

2. Run ant in the <PayPal SDK ROOT>\samples\JSP\ folder.